package main

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"encoding/xml"
	"flag"
	"fmt"
	"html"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/Microsoft/go-winio"
)

const (
	configFile          = "config.ini"
	defaultMpvPath      = `C:\Program Files\mpv\mpv.exe`              // Windows 默认 mpv 路径
	defaultPort         = 9000                                        // 默认 HTTP 端口
	pipeName            = `\\.\pipe\go-dlna-renderer`                 // Windows 命名管道名称
	deviceUUID          = "uuid:550e8400-e29b-41d4-a716-446655440000" // 设备唯一标识符
	defaultFriendlyName = "go投屏接收器"                                   // 默认设备友好名称
	multicastAddr       = "239.255.255.250:1900"                      // SSDP 多播地址
	notifyInterval      = 10 * time.Minute                            // 设备通知间隔

	// Buffer sizes
	mpvReadBufferSize   = 4096 // mpv 读取缓冲区大小
	ssdpReadBufferSize  = 2048 // SSDP 读取缓冲区大小
	mpvResponseChanSize = 20   // mpv 响应通道缓冲区大小

	// Timeouts
	mpvCommandTimeout = 500 * time.Millisecond // mpv 命令超时时间

	// Instance IDs
	defaultInstanceID = "0" // 默认实例 ID
	defaultSpeed      = "1" // 默认播放速度

	// GENA 订阅相关
	defaultSubscriptionTimeout = 1800 // 30分钟，默认订阅超时时间
	eventQueueSize             = 10   // 事件队列大小

	maxConnectAttempts   = 30                                                  // 最大连接尝试次数
	connectRetryInterval = 400 * time.Millisecond                              // 连接重试间隔
	ssdpDiscoverHeader   = `"ssdp:discover"`                                   // SSDP 发现协议头
	cacheControlMaxAge   = "max-age=1800"                                      // 缓存控制：最大生存时间
	contentTypeXML       = "text/xml; charset=\"utf-8\""                       // XML 内容类型
	cacheControlNoCache  = "no-cache, must-revalidate"                         // 缓存控制：不缓存
	serverHeader         = "Microsoft-Windows-NT/10.0 UPnP/1.0 GoRenderer/1.0" // 服务器标识
)

// Subscription 表示一个 GENA 订阅
type Subscription struct {
	SID       string    // Subscription ID
	Callbacks []string  // 回调 URL 列表
	Timeout   int       // 超时时间（秒），0 表示无限
	ExpiresAt time.Time // 过期时间
	Service   string    // 服务名称 (AVTransport, RenderingControl, ConnectionManager)
	Sequence  uint32    // 事件序列号
}

// SubscriptionManager 管理所有订阅
type SubscriptionManager struct {
	mu            sync.RWMutex
	subscriptions map[string]*Subscription // SID -> Subscription
	eventChan     chan EventNotification   // 事件通知通道
}

// EventNotification 表示一个事件通知
type EventNotification struct {
	Service string            // 服务名称
	Props   map[string]string // 属性名和值
}

var (
	verbose          bool
	localIP          string
	httpPort         int
	mpvPath          string
	friendlyName     string
	mpvCmd           *exec.Cmd
	pipeConn         net.Conn
	udpConn          net.Conn // 全局 UDP 连接，用于复用
	udpConnMu        sync.Mutex
	currentURI       string
	currentURIMu     sync.RWMutex
	transportState   = "STOPPED" // 当前传输状态
	transportStatus  = "OK"      // 传输状态
	transportStateMu sync.RWMutex
	mpvResponseChan  = make(chan map[string]interface{}, mpvResponseChanSize) // mpv 响应通道
	mpvRequestID     uint32
	mpvRequestIDMu   sync.Mutex
	subManager       *SubscriptionManager // 订阅管理器
)

func main() {
	log.SetFlags(log.LstdFlags | log.Lshortfile)

	// 解析命令行参数
	flag.BoolVar(&verbose, "v", false, "verbose mode")
	flag.BoolVar(&verbose, "verbose", false, "verbose mode")
	flag.Parse()

	// 初始化订阅管理器
	subManager = NewSubscriptionManager()
	go subManager.RunEventDispatcher()

	// 设置退出时清理资源
	defer cleanup()

	if err := loadConfig(); err != nil {
		log.Fatal(err)
	}

	// 默认只打印配置信息
	if !verbose {
		ip, _ := getLocalIP()
		fmt.Printf("配置: mpv=%s   http_port=%d\n", mpvPath, httpPort)
		fmt.Printf("本机局域网 IP: %s\n", ip)
		fmt.Println("使用 -v 或 --verbose 查看详细日志")
	}

	var err error
	localIP, err = getLocalIP()
	if err != nil {
		log.Printf("警告: %v", err)
		// 尝试其他方法获取 IP
		addrs, err := net.InterfaceAddrs()
		if err == nil {
			for _, addr := range addrs {
				if ipnet, ok := addr.(*net.IPNet); ok && !ipnet.IP.IsLoopback() && ipnet.IP.To4() != nil {
					localIP = ipnet.IP.String()
					break
				}
			}
		}
		if localIP == "" {
			log.Fatal("无法获取本机局域网 IP，请检查网络")
		}
	}
	vlog("本机局域网 IP: %s", localIP)

	if err := startMpv(); err != nil {
		log.Fatal(err)
	}

	pipeConn, err = dialMPVPipeWithRetry()
	if err != nil {
		log.Fatal("无法连接到 mpv named pipe: ", err)
	}
	vlog("成功连接到 mpv IPC named pipe (使用 go-winio)")

	// 订阅 mpv 的 pause 属性变化事件
	sendMpvJSON(map[string]interface{}{
		"command": []interface{}{"observe_property", 1, "pause"},
	})
	vlog("已订阅 mpv pause 属性变化事件")

	// 创建通道用于检测 readMPVResponses 协程退出
	mpvResponseDone := make(chan struct{})

	// 启动读取 mpv 回复的 goroutine
	go func() {
		readMPVResponses(pipeConn)
		close(mpvResponseDone)
	}()

	// 立即发送 NOTIFY alive
	go sendNotifyAlives()

	// 定时 alive
	go func() {
		ticker := time.NewTicker(notifyInterval)
		defer ticker.Stop()
		for range ticker.C {
			sendNotifyAlives()
		}
	}()

	// 监听 SSDP M-SEARCH (UDP 1900 多播)
	go listenSSDP()

	// HTTP 服务
	http.HandleFunc("/description.xml", descriptionHandler)
	http.HandleFunc("/AVTransport/control", avTransportHandler)
	http.HandleFunc("/AVTransport/event", avTransportEventHandler)
	http.HandleFunc("/AVTransport/scpd.xml", scpdHandler)
	http.HandleFunc("/ConnectionManager/control", connectionManagerHandler)
	http.HandleFunc("/ConnectionManager/event", connectionManagerEventHandler)
	http.HandleFunc("/ConnectionManager/scpd.xml", connectionManagerScpdHandler)
	http.HandleFunc("/RenderingControl/control", renderingControlHandler)
	http.HandleFunc("/RenderingControl/event", renderingControlEventHandler)
	http.HandleFunc("/RenderingControl/scpd.xml", renderingControlScpdHandler)

	vlog("HTTP Renderer 服务启动: http://%s:%d", localIP, httpPort)

	// 启动 HTTP 服务器
	server := &http.Server{Addr: fmt.Sprintf(":%d", httpPort)}
	go func() {
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatal(err)
		}
	}()

	// 等待 readMPVResponses 协程退出，然后退出应用程序
	<-mpvResponseDone
	vlog("readMPVResponses 协程退出，正在关闭应用程序...")
	server.Shutdown(context.Background())
	cleanup()
	os.Exit(0)
}

// vlog 只在 verbose 模式下输出日志
func vlog(format string, v ...interface{}) {
	if verbose {
		log.Printf(format, v...)
	}
}

func loadConfig() error {
	if _, err := os.Stat(configFile); os.IsNotExist(err) {
		fmt.Println("配置文件 config.ini 不存在，开始初始化配置...")
		fmt.Println("请输入以下配置信息：")

		// 提示用户输入 mpv 路径
		fmt.Printf("请输入 mpv 可执行文件路径（默认: %s）: ", defaultMpvPath)
		inputMpvPath := readInput()
		if inputMpvPath == "" {
			inputMpvPath = defaultMpvPath
		}

		// 提示用户输入 friendly name
		fmt.Printf("请输入设备友好名称（默认: %s）: ", defaultFriendlyName)
		inputFriendlyName := readInput()
		if inputFriendlyName == "" {
			inputFriendlyName = defaultFriendlyName
		}

		// 提示用户输入 http port
		fmt.Printf("请输入 HTTP 端口（默认: %d）: ", defaultPort)
		inputPort := readInput()
		port := defaultPort
		if inputPort != "" {
			if p, err := strconv.Atoi(inputPort); err == nil && p > 0 && p <= 65535 {
				port = p
			} else {
				fmt.Printf("无效的端口号，使用默认值: %d\n", defaultPort)
			}
		}

		// 创建配置文件
		content := fmt.Sprintf("[config]\nmpv_path = %s\nfriendly_name = %s\nhttp_port = %d\n", inputMpvPath, inputFriendlyName, port)
		if err := os.WriteFile(configFile, []byte(content), 0644); err != nil {
			return fmt.Errorf("创建 config.ini 失败: %w", err)
		}
		fmt.Println("配置文件已创建: config.ini")
		fmt.Println()
	}

	data, err := os.ReadFile(configFile)
	if err != nil {
		return fmt.Errorf("读取 config.ini 失败: %w", err)
	}

	config := parseINI(string(data))
	mpvPath = config["mpv_path"]
	if mpvPath == "" {
		mpvPath = defaultMpvPath
	}

	// 读取 friendly_name 配置
	if fn := config["friendly_name"]; fn != "" {
		friendlyName = fn
	} else {
		friendlyName = defaultFriendlyName
	}
	if p, err := strconv.Atoi(config["http_port"]); err == nil && p > 0 {
		httpPort = p
	} else {
		httpPort = defaultPort
	}

	if _, err := os.Stat(mpvPath); os.IsNotExist(err) {
		return fmt.Errorf("mpv 可执行文件未找到: %s\n请修改 config.ini 中的 mpv_path", mpvPath)
	}
	vlog("配置: mpv=%s   friendly_name=%s   http_port=%d", mpvPath, friendlyName, httpPort)
	return nil
}

// readInput 从标准输入读取一行
func readInput() string {
	var input string
	fmt.Scanln(&input)
	return strings.TrimSpace(input)
}

func parseINI(s string) map[string]string {
	m := make(map[string]string)
	lines := strings.Split(s, "\n")
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, ";") || strings.HasPrefix(line, "#") {
			continue
		}
		parts := strings.SplitN(line, "=", 2)
		if len(parts) == 2 {
			m[strings.TrimSpace(parts[0])] = strings.TrimSpace(parts[1])
		}
	}
	return m
}

func getLocalIP() (string, error) {
	conn, err := net.Dial("udp", "8.8.8.8:53")
	if err != nil {
		return "", fmt.Errorf("failed to get local IP: %w", err)
	}
	defer conn.Close()
	return strings.Split(conn.LocalAddr().String(), ":")[0], nil
}

func startMpv() error {
	cmd := exec.Command(mpvPath,
		"--idle=yes",
		"--input-ipc-server="+pipeName,
		"--force-window=yes",
		"--no-terminal",
		"--keep-open=always",
	)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	if err := cmd.Start(); err != nil {
		return fmt.Errorf("启动 mpv 失败: %w", err)
	}
	mpvCmd = cmd
	vlog("mpv 已启动（idle + ipc-server）")
	return nil
}

func dialMPVPipeWithRetry() (net.Conn, error) {
	var conn net.Conn
	var err error

	for attempt := 1; attempt <= maxConnectAttempts; attempt++ {
		conn, err = winio.DialPipe(pipeName, nil)
		if err == nil {
			return conn, nil
		}

		vlog("尝试连接 mpv pipe (%d/%d): %v", attempt, maxConnectAttempts, err)
		time.Sleep(connectRetryInterval)
	}

	return nil, fmt.Errorf("连接 mpv pipe 失败（尝试 %d 次）: %w", maxConnectAttempts, err)
}

func sendMpvJSON(command interface{}) {
	if pipeConn == nil {
		vlog("pipeConn 为 nil，无法发送命令")
		return
	}

	data, err := json.Marshal(command)
	if err != nil {
		vlog("序列化 mpv 命令失败: %v", err)
		return
	}

	data = append(data, '\n')

	_, err = pipeConn.Write(data)
	if err != nil {
		vlog("向 mpv 发送命令失败: %v", err)
	} else {
		vlog("→ mpv IPC: %s", string(data[:len(data)-1]))
	}
}

func readMPVResponses(conn net.Conn) {
	defer func() {
		vlog("mpv IPC 读取协程退出")
	}()

	buf := make([]byte, mpvReadBufferSize)
	for {
		n, err := conn.Read(buf)
		if err != nil {
			if err == io.EOF {
				vlog("mpv IPC pipe 已关闭（EOF）")
			} else {
				vlog("读取 mpv IPC 失败: %v", err)
			}
			return
		}

		if n == 0 {
			continue
		}

		lines := strings.Split(string(buf[:n]), "\n")
		for _, line := range lines {
			line = strings.TrimSpace(line)
			if line == "" {
				continue
			}
			vlog("mpv ← %s", line)

			// 解析 JSON
			var data map[string]interface{}
			if err := json.Unmarshal([]byte(line), &data); err != nil {
				continue
			}

			// 处理事件通知
			if event, ok := data["event"].(string); ok && event == "property-change" {
				if name, ok := data["name"].(string); ok {
					if name == "pause" {
						if isPaused, ok := data["data"].(bool); ok {
							transportStateMu.Lock()
							oldState := transportState
							var newState string
							if isPaused {
								newState = "PAUSED_PLAYBACK"
								transportState = newState
								vlog("[状态同步] mpv pause=true → %s (旧状态: %s)", transportState, oldState)
							} else {
								newState = "PLAYING"
								transportState = newState
								vlog("[状态同步] mpv pause=false → %s (旧状态: %s)", transportState, oldState)
							}
							transportStateMu.Unlock()
							// 发送事件通知
							notifyTransportState(newState)
						}
					}
				}
				continue // 事件通知不需要放入响应通道
			}

			// 命令响应发送到响应通道
			select {
			case mpvResponseChan <- data:
			default:
				vlog("mpv 响应通道已满，丢弃响应")
			}
		}
	}
}

// NewSubscriptionManager 创建新的订阅管理器
func NewSubscriptionManager() *SubscriptionManager {
	return &SubscriptionManager{
		subscriptions: make(map[string]*Subscription),
		eventChan:     make(chan EventNotification, eventQueueSize),
	}
}

// generateSID 生成唯一的订阅 ID
func generateSID() (string, error) {
	hexStr, err := randomHex(8)
	if err != nil {
		return "", err
	}
	return fmt.Sprintf("uuid:%s", strings.ReplaceAll(strings.ToLower(deviceUUID), "uuid:", "")+"-"+hexStr), nil
}

func randomHex(n int) (string, error) {
	bytes := make([]byte, n)
	if _, err := rand.Read(bytes); err != nil {
		return "", fmt.Errorf("failed to generate random bytes: %w", err)
	}
	return hex.EncodeToString(bytes)[:n], nil
}

// AddSubscription 添加新订阅
func (sm *SubscriptionManager) AddSubscription(service string, callbacks []string, timeout int) *Subscription {
	sm.mu.Lock()
	defer sm.mu.Unlock()

	sid, err := generateSID()
	if err != nil {
		vlog("[GENA] 生成 SID 失败: %v", err)
		return nil
	}
	sub := &Subscription{
		SID:       sid,
		Callbacks: callbacks,
		Timeout:   timeout,
		Service:   service,
		Sequence:  0,
	}

	if timeout > 0 {
		sub.ExpiresAt = time.Now().Add(time.Duration(timeout) * time.Second)
	}

	sm.subscriptions[sid] = sub
	vlog("[GENA] 新订阅: SID=%s Service=%s Callbacks=%v Timeout=%d", sid, service, callbacks, timeout)

	return sub
}

// GetSubscription 获取订阅
func (sm *SubscriptionManager) GetSubscription(sid string) *Subscription {
	sm.mu.RLock()
	defer sm.mu.RUnlock()
	return sm.subscriptions[sid]
}

// RenewSubscription 续订
func (sm *SubscriptionManager) RenewSubscription(sid string, timeout int) *Subscription {
	sm.mu.Lock()
	defer sm.mu.Unlock()

	sub, exists := sm.subscriptions[sid]
	if !exists {
		return nil
	}

	if timeout > 0 {
		sub.ExpiresAt = time.Now().Add(time.Duration(timeout) * time.Second)
	} else {
		sub.ExpiresAt = time.Time{} // 无限
	}
	sub.Timeout = timeout

	vlog("[GENA] 续订: SID=%s Timeout=%d", sid, timeout)
	return sub
}

// RemoveSubscription 移除订阅
func (sm *SubscriptionManager) RemoveSubscription(sid string) bool {
	sm.mu.Lock()
	defer sm.mu.Unlock()

	if _, exists := sm.subscriptions[sid]; exists {
		delete(sm.subscriptions, sid)
		vlog("[GENA] 取消订阅: SID=%s", sid)
		return true
	}
	return false
}

// NotifyEvent 发送事件通知
func (sm *SubscriptionManager) NotifyEvent(service string, props map[string]string) {
	select {
	case sm.eventChan <- EventNotification{Service: service, Props: props}:
		// 成功发送事件
	default:
		// 通道已满，尝试非阻塞发送，如果仍然失败则丢弃
		select {
		case sm.eventChan <- EventNotification{Service: service, Props: props}:
			vlog("[GENA] 事件通道繁忙，但成功发送事件: %s", service)
		default:
			vlog("[GENA] 事件通道已满，丢弃事件: %s", service)
			// 可以在这里添加指标统计，记录丢弃的事件数量
		}
	}
}

// RunEventDispatcher 运行事件分发器
func (sm *SubscriptionManager) RunEventDispatcher() {
	// 定期清理过期订阅
	cleanupTicker := time.NewTicker(60 * time.Second)
	defer cleanupTicker.Stop()

	for {
		select {
		case event := <-sm.eventChan:
			sm.dispatchEvent(event)
		case <-cleanupTicker.C:
			sm.cleanupExpired()
		}
	}
}

// dispatchEvent 分发事件给订阅者
func (sm *SubscriptionManager) dispatchEvent(event EventNotification) {
	sm.mu.RLock()
	defer sm.mu.RUnlock()

	for _, sub := range sm.subscriptions {
		if sub.Service != event.Service {
			continue
		}

		// 检查是否过期
		if !sub.ExpiresAt.IsZero() && time.Now().After(sub.ExpiresAt) {
			continue
		}

		// 异步发送事件
		go sm.sendEventToSubscriber(sub, event)
	}
}

// sendEventToSubscriber 发送事件给单个订阅者
func (sm *SubscriptionManager) sendEventToSubscriber(sub *Subscription, event EventNotification) {
	sm.mu.Lock()
	sub.Sequence++
	seq := sub.Sequence
	sm.mu.Unlock()

	// 构建事件 XML
	eventXML := sm.buildEventXML(event.Props, seq)

	// 发送到所有回调 URL
	for _, callback := range sub.Callbacks {
		go func(cb string) {
			sm.sendNotify(cb, sub.SID, seq, eventXML)
		}(callback)
	}
}

// buildEventXML 构建事件 XML
func (sm *SubscriptionManager) buildEventXML(props map[string]string, seq uint32) string {
	var propsXML strings.Builder
	for name, value := range props {
		propsXML.WriteString(fmt.Sprintf(`<e:property><%s>%s</%s></e:property>`, name, value, name))
	}

	return fmt.Sprintf(`<?xml version="1.0"?>
<e:propertyset xmlns:e="urn:schemas-upnp-org:event-1-0">
%s
</e:propertyset>`, propsXML.String())
}

// sendNotify 发送 NOTIFY 请求
func (sm *SubscriptionManager) sendNotify(callbackURL, sid string, seq uint32, body string) {
	// 解析回调 URL（格式如 <http://192.168.1.100:5000/callback>）
	callbackURL = strings.Trim(callbackURL, "<>")

	req, err := http.NewRequest("NOTIFY", callbackURL, strings.NewReader(body))
	if err != nil {
		vlog("[GENA] 创建 NOTIFY 请求失败: %v", err)
		return
	}

	req.Header.Set("CONTENT-TYPE", contentTypeXML)
	req.Header.Set("NT", "upnp:event")
	req.Header.Set("NTS", "upnp:propchange")
	req.Header.Set("SID", sid)
	req.Header.Set("SEQ", fmt.Sprintf("%d", seq))

	client := &http.Client{Timeout: 3 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		vlog("[GENA] 发送 NOTIFY 失败: %v (URL: %s)", err, callbackURL)
		// 连接失败，标记订阅为需要清理（下次清理周期会移除）
		return
	}
	defer func() {
		// 读取并丢弃剩余内容，确保连接可以被复用
		io.Copy(io.Discard, resp.Body)
		resp.Body.Close()
	}()

	// 如果返回 412 Precondition Failed，订阅者可能已重启，清理订阅
	if resp.StatusCode == 412 {
		sm.RemoveSubscription(sid)
		vlog("[GENA] 订阅者返回 412，已清理订阅: SID=%s", sid)
		return
	}

	vlog("[GENA] NOTIFY 发送成功: SID=%s SEQ=%d URL=%s Status=%d", sid, seq, callbackURL, resp.StatusCode)
}

// cleanupExpired 清理过期订阅
func (sm *SubscriptionManager) cleanupExpired() {
	sm.mu.Lock()
	defer sm.mu.Unlock()

	now := time.Now()
	for sid, sub := range sm.subscriptions {
		if !sub.ExpiresAt.IsZero() && now.After(sub.ExpiresAt) {
			delete(sm.subscriptions, sid)
			vlog("[GENA] 清理过期订阅: SID=%s", sid)
		}
	}
}

func cleanup() {
	if pipeConn != nil {
		sendMpvJSON(map[string]interface{}{"command": []interface{}{"quit"}})
		pipeConn.Close()
		pipeConn = nil
	}
	udpConnMu.Lock()
	if udpConn != nil {
		udpConn.Close()
		udpConn = nil
	}
	udpConnMu.Unlock()
	if mpvCmd != nil && mpvCmd.Process != nil {
		mpvCmd.Process.Kill()
		mpvCmd.Wait()
	}
	vlog("程序清理完成")
}

func sendNotifyAlives() {
	types := []string{
		"upnp:rootdevice",
		"uuid:" + deviceUUID,
		"urn:schemas-upnp-org:device:MediaRenderer:1",
		"urn:schemas-upnp-org:service:AVTransport:1",
		"urn:schemas-upnp-org:service:ConnectionManager:1",
		"urn:schemas-upnp-org:service:RenderingControl:1",
	}

	location := fmt.Sprintf("http://%s:%d/description.xml", localIP, httpPort)

	// 获取或创建 UDP 连接
	udpConnMu.Lock()
	if udpConn == nil {
		conn, err := net.Dial("udp", multicastAddr)
		if err != nil {
			udpConnMu.Unlock()
			vlog("创建 UDP 连接失败: %v", err)
			return
		}
		udpConn = conn
	}
	conn := udpConn
	udpConnMu.Unlock()

	for _, t := range types {
		usn := fmt.Sprintf("%s::%s", deviceUUID, t)
		if t == "upnp:rootdevice" {
			usn = deviceUUID + "::upnp:rootdevice"
		}

		msg := fmt.Sprintf(
			"NOTIFY * HTTP/1.1\r\n"+
				"HOST: 239.255.255.250:1900\r\n"+
				"CACHE-CONTROL: %s\r\n"+
				"LOCATION: %s\r\n"+
				"NT: %s\r\n"+
				"NTS: ssdp:alive\r\n"+
				"SERVER: %s\r\n"+
				"USN: %s\r\n"+
				"\r\n",
			cacheControlMaxAge, location, t, serverHeader, usn,
		)

		_, err := conn.Write([]byte(msg))
		if err != nil {
			vlog("发送 NOTIFY alive 失败: %v", err)
			// 连接可能已失效，重置连接
			udpConnMu.Lock()
			udpConn.Close()
			udpConn = nil
			udpConnMu.Unlock()
			return
		} else {
			vlog("发送 NOTIFY alive: %s", t)
		}
	}
}

func listenSSDP() {
	addr, err := net.ResolveUDPAddr("udp", multicastAddr)
	if err != nil {
		log.Fatal("ResolveUDPAddr 失败:", err)
	}

	conn, err := net.ListenMulticastUDP("udp", nil, addr)
	if err != nil {
		log.Fatal("监听 SSDP 多播失败:", err)
	}
	defer conn.Close()

	vlog("已监听 SSDP 多播 (1900)，等待 M-SEARCH...")

	buf := make([]byte, ssdpReadBufferSize)
	for {
		n, src, err := conn.ReadFromUDP(buf)
		if err != nil {
			vlog("SSDP 读取错误: %v", err)
			continue
		}

		msg := string(buf[:n])
		if !strings.HasPrefix(msg, "M-SEARCH * HTTP/1.1") {
			continue
		}

		st := getHeader(msg, "ST")
		man := getHeader(msg, "MAN")
		if man != `"ssdp:discover"` {
			continue
		}

		vlog("收到 M-SEARCH from %s | ST: %s", src, st)

		// 判断是否需要响应
		shouldRespond := false
		switch st {
		case "ssdp:all", "upnp:rootdevice",
			"uuid:" + deviceUUID,
			"urn:schemas-upnp-org:device:MediaRenderer:1",
			"urn:schemas-upnp-org:service:AVTransport:1",
			"urn:schemas-upnp-org:service:ConnectionManager:1",
			"urn:schemas-upnp-org:service:RenderingControl:1":
			shouldRespond = true
		}

		if !shouldRespond {
			continue
		}

		sendMSearchResponse(conn, src, st)
	}
}

func getHeader(msg, key string) string {
	lines := strings.Split(msg, "\r\n")
	prefix := strings.ToUpper(key) + ":"
	for _, line := range lines {
		if strings.HasPrefix(strings.ToUpper(line), prefix) {
			return strings.TrimSpace(line[len(key)+1:])
		}
	}
	return ""
}

func buildSOAPResponse(action, service string) string {
	return fmt.Sprintf(`<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:%sResponse xmlns:u="urn:schemas-upnp-org:service:%s:1"/></s:Body></s:Envelope>`, action, service)
}

func buildTransportInfoResponse(state, status string) string {
	return fmt.Sprintf(`<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:GetTransportInfoResponse xmlns:u="urn:schemas-upnp-org:service:AVTransport:1"><CurrentTransportState>%s</CurrentTransportState><CurrentTransportStatus>%s</CurrentTransportStatus><CurrentSpeed>%s</CurrentSpeed></u:GetTransportInfoResponse></s:Body></s:Envelope>`, state, status, defaultSpeed)
}

func buildPositionInfoResponse(duration, position, uri string) string {
	return fmt.Sprintf(`<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:GetPositionInfoResponse xmlns:u="urn:schemas-upnp-org:service:AVTransport:1"><Track>1</Track><TrackDuration>%s</TrackDuration><TrackURI>%s</TrackURI><RelTime>%s</RelTime></u:GetPositionInfoResponse></s:Body></s:Envelope>`, duration, html.EscapeString(uri), position)
}

func buildGetProtocolInfoResponse(source, sink string) string {
	return fmt.Sprintf(`<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:GetProtocolInfoResponse xmlns:u="urn:schemas-upnp-org:service:ConnectionManager:1"><Source>%s</Source><Sink>%s</Sink></u:GetProtocolInfoResponse></s:Body></s:Envelope>`, source, sink)
}

func sendMSearchResponse(conn *net.UDPConn, to *net.UDPAddr, st string) {
	location := fmt.Sprintf("http://%s:%d/description.xml", localIP, httpPort)
	usn := fmt.Sprintf("%s::%s", deviceUUID, st)
	if st == "upnp:rootdevice" {
		usn = deviceUUID + "::upnp:rootdevice"
	} else if st == "uuid:"+deviceUUID {
		usn = deviceUUID
	}

	response := fmt.Sprintf(
		"HTTP/1.1 200 OK\r\n"+
			"CACHE-CONTROL: %s\r\n"+
			"EXT:\r\n"+
			"LOCATION: %s\r\n"+
			"SERVER: %s\r\n"+
			"ST: %s\r\n"+
			"USN: %s\r\n"+
			"\r\n",
		cacheControlMaxAge, location, serverHeader, st, usn,
	)

	_, err := conn.WriteToUDP([]byte(response), to)
	if err != nil {
		vlog("发送 M-SEARCH 响应失败: %v", err)
	} else {
		vlog("已回复 M-SEARCH → %s | ST: %s", to, st)
	}
}

// parseTimeout 解析 Timeout 头
func parseTimeout(timeoutStr string) int {
	if timeoutStr == "" || timeoutStr == "Second-infinite" {
		return 0 // 无限
	}
	if strings.HasPrefix(timeoutStr, "Second-") {
		val := strings.TrimPrefix(timeoutStr, "Second-")
		if t, err := strconv.Atoi(val); err == nil {
			return t
		}
	}
	return defaultSubscriptionTimeout
}

// parseCallbacks 解析 Callback 头
func parseCallbacks(callbackStr string) []string {
	// Callback 格式: <http://...> <http://...>
	var callbacks []string
	parts := strings.Split(callbackStr, ">")
	for _, part := range parts {
		part = strings.TrimSpace(part)
		if strings.HasPrefix(part, "<") {
			callbacks = append(callbacks, part+">")
		}
	}
	return callbacks
}

// genaEventHandler 通用 GENA 事件处理器
func genaEventHandler(w http.ResponseWriter, r *http.Request, service string) {
	switch r.Method {
	case "SUBSCRIBE":
		handleSubscribe(w, r, service)
	case "UNSUBSCRIBE":
		handleUnsubscribe(w, r)
	default:
		vlog("[GENA] 不支持的请求方法: %s %s", r.Method, service)
		http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
	}
}

// handleSubscribe 处理 SUBSCRIBE 请求
func handleSubscribe(w http.ResponseWriter, r *http.Request, service string) {
	sid := r.Header.Get("SID")
	callback := r.Header.Get("CALLBACK")
	timeoutStr := r.Header.Get("TIMEOUT")

	var sub *Subscription

	// 续订：有 SID 但没有 CALLBACK
	if sid != "" && callback == "" {
		timeout := parseTimeout(timeoutStr)
		sub = subManager.RenewSubscription(sid, timeout)
		if sub == nil {
			vlog("[GENA] 续订失败，订阅不存在: SID=%s", sid)
			http.Error(w, "Precondition Failed", http.StatusPreconditionFailed)
			return
		}
		vlog("[GENA] 续订成功: SID=%s", sid)
	} else if sid == "" && callback != "" {
		// 新订阅：有 CALLBACK 但没有 SID
		callbacks := parseCallbacks(callback)
		if len(callbacks) == 0 {
			vlog("[GENA] 新订阅失败，无效的 CALLBACK")
			http.Error(w, "Bad Request", http.StatusBadRequest)
			return
		}
		timeout := parseTimeout(timeoutStr)
		sub = subManager.AddSubscription(service, callbacks, timeout)

		// 发送初始事件
		go sendInitialEvent(service, sub.SID)
	} else {
		vlog("[GENA] 订阅请求无效: SID=%s CALLBACK=%s", sid, callback)
		http.Error(w, "Bad Request", http.StatusBadRequest)
		return
	}

	// 响应
	w.Header().Set("SID", sub.SID)
	if sub.Timeout > 0 {
		w.Header().Set("TIMEOUT", fmt.Sprintf("Second-%d", sub.Timeout))
	} else {
		w.Header().Set("TIMEOUT", "Second-infinite")
	}
	w.Header().Set("Server", serverHeader)
	w.WriteHeader(http.StatusOK)
	vlog("[GENA] SUBSCRIBE 响应: SID=%s Service=%s", sub.SID, service)
}

// handleUnsubscribe 处理 UNSUBSCRIBE 请求
func handleUnsubscribe(w http.ResponseWriter, r *http.Request) {
	sid := r.Header.Get("SID")
	if sid == "" {
		http.Error(w, "Bad Request", http.StatusBadRequest)
		return
	}

	if subManager.RemoveSubscription(sid) {
		w.WriteHeader(http.StatusOK)
		vlog("[GENA] UNSUBSCRIBE 成功: SID=%s", sid)
	} else {
		http.Error(w, "Precondition Failed", http.StatusPreconditionFailed)
		vlog("[GENA] UNSUBSCRIBE 失败，订阅不存在: SID=%s", sid)
	}
}

// sendInitialEvent 发送初始事件
func sendInitialEvent(service, sid string) {
	// 等待一小段时间确保订阅者准备好
	time.Sleep(100 * time.Millisecond)

	sub := subManager.GetSubscription(sid)
	if sub == nil {
		return
	}

	// 直接构建并发送事件
	subManager.mu.Lock()
	sub.Sequence++
	seq := sub.Sequence
	subManager.mu.Unlock()

	var props map[string]string
	switch service {
	case "AVTransport":
		transportStateMu.RLock()
		state := transportState
		transportStateMu.RUnlock()
		currentURIMu.RLock()
		uri := currentURI
		currentURIMu.RUnlock()
		props = map[string]string{
			"TransportState":         state,
			"TransportStatus":        "OK",
			"AVTransportURI":         uri,
			"AVTransportURIMetaData": "",
		}
	case "RenderingControl":
		props = map[string]string{}
	case "ConnectionManager":
		props = map[string]string{
			"SourceProtocolInfo": "",
			"SinkProtocolInfo":   "http-get:*:*:*,http-get:*:*:*",
		}
	}

	eventXML := subManager.buildEventXML(props, seq)
	for _, callback := range sub.Callbacks {
		go subManager.sendNotify(callback, sid, seq, eventXML)
	}
}

func boolToInt(b bool) int {
	if b {
		return 1
	}
	return 0
}

// avTransportEventHandler AVTransport 服务事件处理器
func avTransportEventHandler(w http.ResponseWriter, r *http.Request) {
	genaEventHandler(w, r, "AVTransport")
}

// connectionManagerEventHandler ConnectionManager 服务事件处理器
func connectionManagerEventHandler(w http.ResponseWriter, r *http.Request) {
	genaEventHandler(w, r, "ConnectionManager")
}

// renderingControlEventHandler RenderingControl 服务事件处理器
func renderingControlEventHandler(w http.ResponseWriter, r *http.Request) {
	genaEventHandler(w, r, "RenderingControl")
}

func descriptionHandler(w http.ResponseWriter, r *http.Request) {
	xml := fmt.Sprintf(`<?xml version="1.0" encoding="utf-8"?>
<root xmlns="urn:schemas-upnp-org:device-1-0">
  <specVersion><major>1</major><minor>0</minor></specVersion>
  <device>
    <deviceType>urn:schemas-upnp-org:device:MediaRenderer:1</deviceType>
    <friendlyName>%s</friendlyName>
    <manufacturer>自定义 DLNA</manufacturer>
    <modelName>Go MPV Renderer</modelName>
    <UDN>%s</UDN>
    <serviceList>
      <service>
        <serviceType>urn:schemas-upnp-org:service:AVTransport:1</serviceType>
        <serviceId>urn:upnp-org:serviceId:AVTransport</serviceId>
        <controlURL>/AVTransport/control</controlURL>
        <eventSubURL>/AVTransport/event</eventSubURL>
        <SCPDURL>/AVTransport/scpd.xml</SCPDURL>
      </service>
      <service>
        <serviceType>urn:schemas-upnp-org:service:ConnectionManager:1</serviceType>
        <serviceId>urn:upnp-org:serviceId:ConnectionManager</serviceId>
        <controlURL>/ConnectionManager/control</controlURL>
        <eventSubURL>/ConnectionManager/event</eventSubURL>
        <SCPDURL>/ConnectionManager/scpd.xml</SCPDURL>
      </service>
      <service>
        <serviceType>urn:schemas-upnp-org:service:RenderingControl:1</serviceType>
        <serviceId>urn:upnp-org:serviceId:RenderingControl</serviceId>
        <controlURL>/RenderingControl/control</controlURL>
        <eventSubURL>/RenderingControl/event</eventSubURL>
        <SCPDURL>/RenderingControl/scpd.xml</SCPDURL>
      </service>
    </serviceList>
  </device>
</root>`, friendlyName, deviceUUID)

	w.Header().Set("Content-Type", contentTypeXML)
	fmt.Fprint(w, xml)
	vlog("返回 description.xml")
}

func scpdHandler(w http.ResponseWriter, r *http.Request) {
	scpd := `<?xml version="1.0" encoding="utf-8"?>
<scpd xmlns="urn:schemas-upnp-org:service-1-0">
	<specVersion><major>1</major><minor>0</minor></specVersion>
	<actionList>
		<action>
			<name>GetPositionInfo</name>
			<argumentList>
			<argument>
				<name>InstanceID</name>
				<direction>in</direction>
				<relatedStateVariable>A_ARG_TYPE_InstanceID</relatedStateVariable>
			</argument>
			<argument>
				<name>TrackDuration</name>
				<direction>out</direction>
				<relatedStateVariable>CurrentTrackDuration</relatedStateVariable>
			</argument>
			<argument>
				<name>TrackURI</name>
				<direction>out</direction>
				<relatedStateVariable>CurrentTrackURI</relatedStateVariable>
			</argument>
			<argument>
				<name>RelTime</name>
				<direction>out</direction>
				<relatedStateVariable>RelativeTimePosition</relatedStateVariable>
			</argument>
			</argumentList>
		</action>
		<action>
			<name>GetTransportInfo</name>
			<argumentList>
				<argument>
					<name>InstanceID</name>
					<direction>in</direction>
					<relatedStateVariable>A_ARG_TYPE_InstanceID</relatedStateVariable>
				</argument>
				<argument>
					<name>CurrentTransportState</name>
					<direction>out</direction>
					<relatedStateVariable>TransportState</relatedStateVariable>
				</argument>
				<argument>
					<name>CurrentTransportStatus</name>
					<direction>out</direction>
					<relatedStateVariable>TransportStatus</relatedStateVariable>
				</argument>
				<argument>
					<name>CurrentSpeed</name>
					<direction>out</direction>
					<relatedStateVariable>TransportPlaySpeed</relatedStateVariable>
				</argument>
			</argumentList>
		</action>
		<action>
			<name>SetAVTransportURI</name>
			<argumentList>
				<argument>
					<name>InstanceID</name>
					<direction>in</direction>
					<relatedStateVariable>A_ARG_TYPE_InstanceID</relatedStateVariable>
				</argument>
				<argument>
					<name>CurrentURI</name>
					<direction>in</direction>
					<relatedStateVariable>AVTransportURI</relatedStateVariable>
				</argument>
				<argument>
					<name>CurrentURIMetaData</name>
					<direction>in</direction>
					<relatedStateVariable>AVTransportURIMetaData</relatedStateVariable>
				</argument>
			</argumentList>
		</action>
		<action>
			<name>Stop</name>
			<argumentList>
				<argument>
					<name>InstanceID</name>
					<direction>in</direction>
					<relatedStateVariable>A_ARG_TYPE_InstanceID</relatedStateVariable>
				</argument>
			</argumentList>
		</action>
		<action>
			<name>Play</name>
			<argumentList>
				<argument>
					<name>InstanceID</name>
					<direction>in</direction>
					<relatedStateVariable>A_ARG_TYPE_InstanceID</relatedStateVariable>
				</argument>
				<argument>
					<name>Speed</name>
					<direction>in</direction>
					<relatedStateVariable>TransportPlaySpeed</relatedStateVariable>
				</argument>
			</argumentList>
		</action>
		<action>
			<name>Seek</name>
			<argumentList>
				<argument>
					<name>InstanceID</name>
					<direction>in</direction>
					<relatedStateVariable>A_ARG_TYPE_InstanceID</relatedStateVariable>
				</argument>
				<argument>
					<name>Unit</name>
					<direction>in</direction>
					<relatedStateVariable>A_ARG_TYPE_SeekMode</relatedStateVariable>
				</argument>
				<argument>
					<name>Target</name>
					<direction>in</direction>
					<relatedStateVariable>A_ARG_TYPE_SeekTarget</relatedStateVariable>
				</argument>
			</argumentList>
		</action>
		<action>
			<name>Pause</name>
			<argumentList>
				<argument>
					<name>InstanceID</name>
					<direction>in</direction>
					<relatedStateVariable>A_ARG_TYPE_InstanceID</relatedStateVariable>
				</argument>
			</argumentList>
		</action>
	</actionList>
	<serviceStateTable>
		<stateVariable sendEvents="no">
			<name>CurrentTrackMetaData</name>
			<dataType>string</dataType>
			<defaultValue>NOT_IMPLEMENTED</defaultValue>
		</stateVariable>
		<stateVariable sendEvents="no">
			<name>CurrentTrackURI</name>
			<dataType>string</dataType>
		</stateVariable>
		<stateVariable sendEvents="no">
			<name>AVTransportURIMetaData</name>
			<dataType>string</dataType>
			<defaultValue>NOT_IMPLEMENTED</defaultValue>
		</stateVariable>
		<stateVariable sendEvents="no">
			<name>RelativeTimePosition</name>
			<dataType>string</dataType>
		</stateVariable>
		<stateVariable sendEvents="no">
			<name>TransportStatus</name>
			<dataType>string</dataType>
			<allowedValueList>
				<allowedValue>OK</allowedValue>
				<allowedValue>ERROR_OCCURRED</allowedValue>
			</allowedValueList>
		</stateVariable>
		<stateVariable sendEvents="no">
			<name>A_ARG_TYPE_SeekMode</name>
			<dataType>string</dataType>
			<allowedValueList>
				<allowedValue>REL_TIME</allowedValue>
			</allowedValueList>
		</stateVariable>
		<stateVariable sendEvents="no">
			<name>TransportPlaySpeed</name>
			<dataType>string</dataType>
			<defaultValue>1</defaultValue>
		</stateVariable>
		<stateVariable sendEvents="no">
			<name>A_ARG_TYPE_SeekTarget</name>
			<dataType>string</dataType>
		</stateVariable>
		<stateVariable sendEvents="no">
			<name>AbsoluteTimePosition</name>
			<dataType>string</dataType>
		</stateVariable>
		<stateVariable sendEvents="no">
			<name>CurrentTrackDuration</name>
			<dataType>string</dataType>
		</stateVariable>
		<stateVariable sendEvents="no">
			<name>TransportState</name>
			<dataType>string</dataType>
			<allowedValueList>
				<allowedValue>STOPPED</allowedValue>
				<allowedValue>PLAYING</allowedValue>
				<allowedValue>PAUSED_PLAYBACK</allowedValue>
			</allowedValueList>
		</stateVariable>
		<stateVariable sendEvents="no">
			<name>AVTransportURI</name>
			<dataType>string</dataType>
		</stateVariable>
		<stateVariable sendEvents="no">
			<name>CurrentMediaDuration</name>
			<dataType>string</dataType>
			<defaultValue>00:00:00</defaultValue>
		</stateVariable>
		<stateVariable sendEvents="no">
			<name>A_ARG_TYPE_InstanceID</name>
			<dataType>ui4</dataType>
		</stateVariable>
	</serviceStateTable>
</scpd>`

	w.Header().Set("Content-Type", contentTypeXML)
	w.Header().Set("Cache-Control", cacheControlNoCache)
	fmt.Fprint(w, scpd)
	vlog("返回 AVTransport scpd.xml")
}

func getNextRequestID() uint32 {
	mpvRequestIDMu.Lock()
	defer mpvRequestIDMu.Unlock()
	mpvRequestID++
	return mpvRequestID
}

func sendMpvCommandAndWait(command interface{}) (map[string]interface{}, bool) {
	requestID := getNextRequestID()
	sendMpvJSON(map[string]interface{}{
		"command":    []interface{}{"get_property", command},
		"request_id": requestID,
	})

	// 等待响应，超时 500 毫秒
	timeout := time.After(mpvCommandTimeout)
	for {
		select {
		case response := <-mpvResponseChan:
			if rid, ok := response["request_id"].(float64); ok && uint32(rid) == requestID {
				return response, true
			}
		case <-timeout:
			return nil, false
		}
	}
}

func formatTimeToUPnP(seconds float64) string {
	if seconds <= 0 {
		return "00:00:00"
	}
	hrs := int(seconds) / 3600
	mins := (int(seconds) % 3600) / 60
	secs := int(seconds) % 60
	return fmt.Sprintf("%02d:%02d:%02d", hrs, mins, secs)
}

// parseUPnPTime 将 UPnP 时间格式 (HH:MM:SS) 转换为秒数，支持负数
func parseUPnPTime(timeStr string) float64 {
	parts := strings.Split(timeStr, ":")
	if len(parts) != 3 {
		return 0
	}

	hours, _ := strconv.Atoi(parts[0])
	minutes, _ := strconv.Atoi(parts[1])
	seconds, _ := strconv.Atoi(parts[2])

	totalSeconds := float64(hours*3600 + minutes*60 + seconds)

	return totalSeconds
}

func getMpvPositionInfo() (duration, currentTime float64) {
	// 获取 duration
	response1, ok := sendMpvCommandAndWait("duration")
	if !ok {
		vlog("[GetPositionInfo] 获取 duration 超时或失败")
		return 0, currentTime
	}
	if data, exists := response1["data"]; exists {
		if dur, ok := data.(float64); ok && dur > 0 {
			duration = dur
		} else {
			vlog("[GetPositionInfo] duration 值无效: %v", data)
		}
	}

	// 获取 time-pos
	response2, ok := sendMpvCommandAndWait("time-pos")
	if !ok {
		vlog("[GetPositionInfo] 获取 time-pos 超时或失败")
		return duration, currentTime
	}
	if data, exists := response2["data"]; exists {
		if pos, ok := data.(float64); ok && pos >= 0 {
			currentTime = pos
		} else {
			vlog("[GetPositionInfo] time-pos 值无效: %v", data)
		}
	}

	return duration, currentTime
}

func connectionManagerScpdHandler(w http.ResponseWriter, r *http.Request) {
	scpd := `<?xml version="1.0" encoding="utf-8"?>
<scpd xmlns="urn:schemas-upnp-org:service-1-0">
  <specVersion><major>1</major><minor>0</minor></specVersion>
  <actionList>
    <action>
      <name>GetProtocolInfo</name>
      <argumentList>
        <argument>
          <name>Source</name>
          <direction>out</direction>
          <relatedStateVariable>SourceProtocolInfo</relatedStateVariable>
        </argument>
        <argument>
          <name>Sink</name>
          <direction>out</direction>
          <relatedStateVariable>SinkProtocolInfo</relatedStateVariable>
        </argument>
      </argumentList>
    </action>
  </actionList>
  <serviceStateTable>
    <stateVariable sendEvents="yes">
      <name>SourceProtocolInfo</name>
      <dataType>string</dataType>
    </stateVariable>
    <stateVariable sendEvents="yes">
      <name>SinkProtocolInfo</name>
      <dataType>string</dataType>
    </stateVariable>
  </serviceStateTable>
</scpd>`

	w.Header().Set("Content-Type", contentTypeXML)
	w.Header().Set("Cache-Control", cacheControlNoCache)
	fmt.Fprint(w, scpd)
	vlog("返回 ConnectionManager scpd.xml")
}

func renderingControlScpdHandler(w http.ResponseWriter, r *http.Request) {
	scpd := `<?xml version="1.0" encoding="utf-8"?>
<scpd xmlns="urn:schemas-upnp-org:service-1-0">
  <specVersion><major>1</major><minor>0</minor></specVersion>
  <actionList>
  </actionList>
  <serviceStateTable>
  </serviceStateTable>
</scpd>`

	w.Header().Set("Content-Type", contentTypeXML)
	w.Header().Set("Cache-Control", cacheControlNoCache)
	fmt.Fprint(w, scpd)
	vlog("返回 RenderingControl scpd.xml")
}

func avTransportHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
		return
	}

	body, err := io.ReadAll(r.Body)
	r.Body.Close()
	if err != nil {
		vlog("读取请求体失败: %v", err)
		http.Error(w, "Bad Request", http.StatusBadRequest)
		return
	}

	var env struct {
		XMLName xml.Name `xml:"Envelope"`
		Body    struct {
			SetURI *struct {
				InstanceID string `xml:"InstanceID"`
				CurrentURI string `xml:"CurrentURI"`
			} `xml:"SetAVTransportURI"`
			Play *struct {
				InstanceID string `xml:"InstanceID"`
				Speed      string `xml:"Speed"`
			} `xml:"Play"`
			Pause *struct {
				InstanceID string `xml:"InstanceID"`
			} `xml:"Pause"`
			Stop *struct {
				InstanceID string `xml:"InstanceID"`
			} `xml:"Stop"`
			GetTransportInfo *struct {
				InstanceID string `xml:"InstanceID"`
			} `xml:"GetTransportInfo"`
			GetPositionInfo *struct {
				InstanceID string `xml:"InstanceID"`
			} `xml:"GetPositionInfo"`
			Seek *struct {
				InstanceID string `xml:"InstanceID"`
				Unit       string `xml:"Unit"`
				Target     string `xml:"Target"`
			} `xml:"Seek"`
		} `xml:"Body"`
	}
	if err := xml.Unmarshal(body, &env); err != nil {
		vlog("解析 SOAP 请求失败: %v", err)
		http.Error(w, "Bad Request", http.StatusBadRequest)
		return
	}

	soapAction := strings.Trim(r.Header.Get("SOAPACTION"), "\"")
	action := ""
	if idx := strings.LastIndex(soapAction, "#"); idx > 0 {
		action = soapAction[idx+1:]
	}

	var resp string
	switch action {
	case "SetAVTransportURI":
		resp = handleSetAVTransportURI(env.Body.SetURI)
	case "Play":
		resp = handlePlay(env.Body.Play)
	case "Pause":
		resp = handlePause(env.Body.Pause)
	case "Stop":
		resp = handleStop()
	case "Seek":
		resp = handleSeek(env.Body.Seek)
	case "GetTransportInfo":
		resp = handleGetTransportInfo(env.Body.GetTransportInfo)
	case "GetPositionInfo":
		resp = handleGetPositionInfo(env.Body.GetPositionInfo)
	default:
		vlog("不支持的 SOAP 动作: %s", action)
		http.Error(w, "Unsupported SOAP action", http.StatusBadRequest)
		return
	}

	if resp != "" {
		w.Header().Set("Content-Type", contentTypeXML)
		fmt.Fprint(w, resp)
	} else {
		http.Error(w, "Bad Request", http.StatusBadRequest)
	}
}

func handleSetAVTransportURI(setURI *struct {
	InstanceID string `xml:"InstanceID"`
	CurrentURI string `xml:"CurrentURI"`
}) string {
	if setURI == nil || setURI.InstanceID != defaultInstanceID {
		return ""
	}
	currentURIMu.Lock()
	currentURI = setURI.CurrentURI
	currentURIMu.Unlock()

	sendMpvJSON(map[string]interface{}{
		"command": []interface{}{"loadfile", currentURI, "replace"},
	})
	vlog("[SetURI] %s (已发送 loadfile)", currentURI)

	// 更新状态并发送事件通知
	transportStateMu.Lock()
	transportState = "PLAYING"
	transportStateMu.Unlock()
	notifyAVTransportURI(currentURI)

	return buildSOAPResponse("SetAVTransportURI", "AVTransport")
}

func handlePlay(play *struct {
	InstanceID string `xml:"InstanceID"`
	Speed      string `xml:"Speed"`
}) string {
	if play == nil || play.InstanceID != defaultInstanceID {
		return ""
	}
	currentURIMu.RLock()
	uri := currentURI
	currentURIMu.RUnlock()

	if uri != "" {
		sendMpvJSON(map[string]interface{}{
			"command": []interface{}{"set_property", "pause", false},
		})
		vlog("[Play] %s", uri)

		// 更新状态并发送事件通知
		transportStateMu.Lock()
		transportState = "PLAYING"
		transportStateMu.Unlock()
		notifyTransportState("PLAYING")

		return buildSOAPResponse("Play", "AVTransport")
	}
	return ""
}

func handlePause(pause *struct {
	InstanceID string `xml:"InstanceID"`
}) string {
	if pause == nil || pause.InstanceID != defaultInstanceID {
		return ""
	}
	sendMpvJSON(map[string]interface{}{
		"command": []interface{}{"set_property", "pause", true},
	})

	// 更新状态并发送事件通知（mpv 回调也会更新，但这里提前更新）
	transportStateMu.Lock()
	transportState = "PAUSED_PLAYBACK"
	transportStateMu.Unlock()
	notifyTransportState("PAUSED_PLAYBACK")

	return buildSOAPResponse("Pause", "AVTransport")
}

func handleStop() string {
	sendMpvJSON(map[string]interface{}{
		"command": []interface{}{"stop"},
	})
	sendMpvJSON(map[string]interface{}{
		"command": []interface{}{"seek", 0, "absolute"},
	})

	// 更新状态并发送事件通知
	transportStateMu.Lock()
	transportState = "STOPPED"
	transportStateMu.Unlock()
	notifyTransportState("STOPPED")

	return buildSOAPResponse("Stop", "AVTransport")
}

func handleSeek(seek *struct {
	InstanceID string `xml:"InstanceID"`
	Unit       string `xml:"Unit"`
	Target     string `xml:"Target"`
}) string {
	if seek == nil || seek.InstanceID != defaultInstanceID {
		return ""
	}
	unit := seek.Unit
	target := seek.Target

	if unit != "REL_TIME" {
		vlog("[Seek] 不支持的 seek unit: %s (仅支持 REL_TIME)", unit)
		return ""
	}

	targetSeconds := parseUPnPTime(target)

	sendMpvJSON(map[string]interface{}{
		"command": []interface{}{"seek", targetSeconds, "absolute"},
	})
	vlog("[Seek] %s: %s (%.2f秒)", unit, target, targetSeconds)
	return buildSOAPResponse("Seek", "AVTransport")
}

func handleGetTransportInfo(getTransportInfo *struct {
	InstanceID string `xml:"InstanceID"`
}) string {
	if getTransportInfo == nil || getTransportInfo.InstanceID != defaultInstanceID {
		return ""
	}
	transportStateMu.RLock()
	state := transportState
	status := transportStatus
	transportStateMu.RUnlock()
	vlog("[GetTransportInfo] 返回状态: " + state)
	return buildTransportInfoResponse(state, status)
}

func handleGetPositionInfo(getPositionInfo *struct {
	InstanceID string `xml:"InstanceID"`
}) string {
	if getPositionInfo == nil || getPositionInfo.InstanceID != defaultInstanceID {
		return ""
	}
	currentURIMu.RLock()
	uri := currentURI
	currentURIMu.RUnlock()

	durationSec, positionSec := getMpvPositionInfo()
	relTimeStr := formatTimeToUPnP(positionSec)

	var durationStr string
	if durationSec <= 0 {
		durationStr = "NOT_IMPLEMENTED"
		vlog("[GetPositionInfo] 检测到直播/无时长流，TrackDuration=NOT_IMPLEMENTED")
	} else {
		durationStr = formatTimeToUPnP(durationSec)
	}

	resp := buildPositionInfoResponse(durationStr, relTimeStr, uri)
	vlog("[GetPositionInfo] 返回: %s / %s   URI: %s", relTimeStr, durationStr, uri)
	return resp
}

func connectionManagerHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
		return
	}

	body, err := io.ReadAll(r.Body)
	r.Body.Close()
	if err != nil {
		vlog("读取请求体失败: %v", err)
		http.Error(w, "Bad Request", http.StatusBadRequest)
		return
	}

	var env struct {
		XMLName xml.Name `xml:"Envelope"`
		Body    struct {
			GetProtocolInfo *struct{} `xml:"GetProtocolInfo"`
		} `xml:"Body"`
	}
	if err := xml.Unmarshal(body, &env); err != nil {
		vlog("解析 SOAP 请求失败: %v", err)
		http.Error(w, "Bad Request", http.StatusBadRequest)
		return
	}

	soapAction := strings.Trim(r.Header.Get("SOAPACTION"), "\"")
	action := ""
	if idx := strings.LastIndex(soapAction, "#"); idx > 0 {
		action = soapAction[idx+1:]
	}

	var resp string
	switch action {
	case "GetProtocolInfo":
		sink := "http-get:*:*:*"
		source := "http-get:*:*:*"
		resp = buildGetProtocolInfoResponse(source, sink)
		vlog("[ConnectionManager] GetProtocolInfo")
	default:
		vlog("不支持的 SOAP 动作: %s", action)
		http.Error(w, "Unsupported SOAP action", http.StatusBadRequest)
		return
	}

	if resp != "" {
		w.Header().Set("Content-Type", contentTypeXML)
		fmt.Fprint(w, resp)
	} else {
		http.Error(w, "Bad Request", http.StatusBadRequest)
	}
}

func renderingControlHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
		return
	}

	body, err := io.ReadAll(r.Body)
	r.Body.Close()
	if err != nil {
		vlog("读取请求体失败: %v", err)
		http.Error(w, "Bad Request", http.StatusBadRequest)
		return
	}

	var env struct {
		XMLName xml.Name `xml:"Envelope"`
		Body    struct {
		} `xml:"Body"`
	}
	if err := xml.Unmarshal(body, &env); err != nil {
		vlog("解析 SOAP 请求失败: %v", err)
		http.Error(w, "Bad Request", http.StatusBadRequest)
		return
	}

	soapAction := strings.Trim(r.Header.Get("SOAPACTION"), "\"")
	action := ""
	if idx := strings.LastIndex(soapAction, "#"); idx > 0 {
		action = soapAction[idx+1:]
	}

	var resp string
	switch action {
	default:
		vlog("不支持的 SOAP 动作: %s", action)
		http.Error(w, "Unsupported SOAP action", http.StatusBadRequest)
		return
	}

	if resp != "" {
		w.Header().Set("Content-Type", contentTypeXML)
		fmt.Fprint(w, resp)
	} else {
		http.Error(w, "Bad Request", http.StatusBadRequest)
	}
}

// notifyTransportState 发送传输状态变化事件
func notifyTransportState(state string) {
	if subManager == nil {
		return
	}
	currentURIMu.RLock()
	uri := currentURI
	currentURIMu.RUnlock()
	subManager.NotifyEvent("AVTransport", map[string]string{
		"TransportState":         state,
		"TransportStatus":        "OK",
		"AVTransportURI":         uri,
		"AVTransportURIMetaData": "",
	})
	vlog("[Event] TransportState → %s", state)
}

// notifyAVTransportURI 发送 URI 变化事件
func notifyAVTransportURI(uri string) {
	if subManager == nil {
		return
	}
	transportStateMu.RLock()
	state := transportState
	transportStateMu.RUnlock()
	subManager.NotifyEvent("AVTransport", map[string]string{
		"TransportState":         state,
		"TransportStatus":        "OK",
		"AVTransportURI":         uri,
		"AVTransportURIMetaData": "",
	})
	vlog("[Event] AVTransportURI → %s", uri)
}
