package main

import (
	"encoding/xml"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"time"
)

const (
	configFile     = "config.ini"
	defaultMpvPath = `C:\Program Files\mpv\mpv.exe`
	defaultPort    = 9000
	pipeName       = `\\.\pipe\go-dlna-renderer`
	deviceUUID     = "uuid:550e8400-e29b-41d4-a716-446655440000"
	friendlyName   = "go投屏接收器"
	multicastAddr  = "239.255.255.250:1900"
	notifyInterval = 20 * time.Minute
)

var (
	localIP    string
	httpPort   int
	mpvPath    string
	mpvCmd     *exec.Cmd
	currentURI string
)

func main() {
	log.SetFlags(log.LstdFlags | log.Lshortfile)

	loadConfig()

	localIP = getLocalIP()
	if localIP == "" {
		log.Fatal("无法获取本机局域网 IP，请检查网络")
	}
	log.Printf("本机局域网 IP: %s", localIP)



	// 立即发送 NOTIFY alive
	go sendNotifyAlives()

	// 定时 alive
	go func() {
		ticker := time.NewTicker(notifyInterval)
		defer ticker.Stop()
		for range ticker.C {
			sendNotifyAlives()
		}
	}()

	// 监听 SSDP M-SEARCH (UDP 1900 多播)
	go listenSSDP()

	// HTTP 服务
	http.HandleFunc("/description.xml", descriptionHandler)
	http.HandleFunc("/AVTransport/control", avTransportHandler)
	http.HandleFunc("/AVTransport/event", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})
	http.HandleFunc("/AVTransport/scpd.xml", scpdHandler)

	log.Printf("HTTP Renderer 服务启动: http://%s:%d", localIP, httpPort)
	log.Fatal(http.ListenAndServe(fmt.Sprintf(":%d", httpPort), nil))
}

func loadConfig() {
	if _, err := os.Stat(configFile); os.IsNotExist(err) {
		content := fmt.Sprintf("[config]\nmpv_path = %s\nhttp_port = %d\n", defaultMpvPath, defaultPort)
		if err := os.WriteFile(configFile, []byte(content), 0644); err != nil {
			log.Fatal("创建 config.ini 失败:", err)
		}
		log.Println("已创建默认 config.ini")
	}

	data, err := os.ReadFile(configFile)
	if err != nil {
		log.Fatal("读取 config.ini 失败:", err)
	}

	config := parseINI(string(data))
	mpvPath = config["mpv_path"]
	if mpvPath == "" {
		mpvPath = defaultMpvPath
	}
	if p, err := strconv.Atoi(config["http_port"]); err == nil && p > 0 {
		httpPort = p
	} else {
		httpPort = defaultPort
	}

	if _, err := os.Stat(mpvPath); os.IsNotExist(err) {
		log.Fatalf("mpv.exe 未找到: %s\n请修改 config.ini 中的 mpv_path", mpvPath)
	}
	log.Printf("配置: mpv=%s   http_port=%d", mpvPath, httpPort)
}

func parseINI(s string) map[string]string {
	m := make(map[string]string)
	lines := strings.Split(s, "\n")
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, ";") || strings.HasPrefix(line, "#") {
			continue
		}
		parts := strings.SplitN(line, "=", 2)
		if len(parts) == 2 {
			m[strings.TrimSpace(parts[0])] = strings.TrimSpace(parts[1])
		}
	}
	return m
}

func getLocalIP() string {
	conn, err := net.Dial("udp", "8.8.8.8:53")
	if err != nil {
		return ""
	}
	defer conn.Close()
	return strings.Split(conn.LocalAddr().String(), ":")[0]
}

func stopMpv() {
	if mpvCmd != nil && mpvCmd.Process != nil {
		log.Println("关闭旧 mpv 实例")
		mpvCmd.Process.Kill()
		mpvCmd.Wait()
		mpvCmd = nil
	}
}

func startMpv(uri string) {
	stopMpv()

	cmd := exec.Command(mpvPath, uri)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	if err := cmd.Start(); err != nil {
		log.Printf("启动 mpv 失败: %v", err)
		return
	}
	mpvCmd = cmd
	log.Printf("mpv 已启动播放: %s", uri)
}

func cleanup() {
	stopMpv()
	log.Println("程序清理完成")
}

func sendNotifyAlives() {
	types := []string{
		"upnp:rootdevice",
		"uuid:" + deviceUUID,
		"urn:schemas-upnp-org:device:MediaRenderer:1",
		"urn:schemas-upnp-org:service:AVTransport:1",
	}

	location := fmt.Sprintf("http://%s:%d/description.xml", localIP, httpPort)
	server := "Microsoft-Windows-NT/10.0 UPnP/1.0 GoRenderer/1.0"

	for _, t := range types {
		usn := fmt.Sprintf("%s::%s", deviceUUID, t)
		if t == "upnp:rootdevice" {
			usn = deviceUUID + "::upnp:rootdevice"
		}

		msg := fmt.Sprintf(
			"NOTIFY * HTTP/1.1\r\n"+
				"HOST: 239.255.255.250:1900\r\n"+
				"CACHE-CONTROL: max-age=1800\r\n"+
				"LOCATION: %s\r\n"+
				"NT: %s\r\n"+
				"NTS: ssdp:alive\r\n"+
				"SERVER: %s\r\n"+
				"USN: %s\r\n"+
				"\r\n",
			location, t, server, usn,
		)

		conn, _ := net.Dial("udp", multicastAddr)
		if conn != nil {
			conn.Write([]byte(msg))
			conn.Close()
			log.Printf("发送 NOTIFY alive: %s", t)
		}
	}
}

func listenSSDP() {
	addr, err := net.ResolveUDPAddr("udp", multicastAddr)
	if err != nil {
		log.Fatal("ResolveUDPAddr 失败:", err)
	}

	conn, err := net.ListenMulticastUDP("udp", nil, addr)
	if err != nil {
		log.Fatal("监听 SSDP 多播失败:", err)
	}
	defer conn.Close()

	log.Println("已监听 SSDP 多播 (1900)，等待 M-SEARCH...")

	buf := make([]byte, 2048)
	for {
		n, src, err := conn.ReadFromUDP(buf)
		if err != nil {
			log.Printf("SSDP 读取错误: %v", err)
			continue
		}

		msg := string(buf[:n])
		if !strings.HasPrefix(msg, "M-SEARCH * HTTP/1.1") {
			continue
		}

		st := getHeader(msg, "ST")
		man := getHeader(msg, "MAN")
		if man != `"ssdp:discover"` {
			continue
		}

		log.Printf("收到 M-SEARCH from %s | ST: %s", src, st)

		// 判断是否需要响应
		shouldRespond := false
		switch st {
		case "ssdp:all", "upnp:rootdevice",
			"uuid:" + deviceUUID,
			"urn:schemas-upnp-org:device:MediaRenderer:1",
			"urn:schemas-upnp-org:service:AVTransport:1":
			shouldRespond = true
		}

		if !shouldRespond {
			continue
		}

		sendMSearchResponse(conn, src, st)
	}
}

func getHeader(msg, key string) string {
	lines := strings.Split(msg, "\r\n")
	for _, line := range lines {
		if strings.HasPrefix(strings.ToUpper(line), strings.ToUpper(key)+":") {
			return strings.TrimSpace(line[len(key)+1:])
		}
	}
	return ""
}

func sendMSearchResponse(conn *net.UDPConn, to *net.UDPAddr, st string) {
	location := fmt.Sprintf("http://%s:%d/description.xml", localIP, httpPort)
	usn := fmt.Sprintf("%s::%s", deviceUUID, st)
	if st == "upnp:rootdevice" {
		usn = deviceUUID + "::upnp:rootdevice"
	}
	if st == "uuid:" + deviceUUID {
		usn = deviceUUID
	}

	response := fmt.Sprintf(
		"HTTP/1.1 200 OK\r\n"+
			"CACHE-CONTROL: max-age=1800\r\n"+
			"EXT:\r\n"+
			"LOCATION: %s\r\n"+
			"SERVER: Microsoft-Windows-NT/10.0 UPnP/1.0 GoRenderer/1.0\r\n"+
			"ST: %s\r\n"+
			"USN: %s\r\n"+
			"\r\n",
		location, st, usn,
	)

	// 单播回复
	_, err := conn.WriteToUDP([]byte(response), to)
	if err != nil {
		log.Printf("发送 M-SEARCH 响应失败: %v", err)
	} else {
		log.Printf("已回复 M-SEARCH → %s | ST: %s", to, st)
	}
}

func descriptionHandler(w http.ResponseWriter, r *http.Request) {
	xml := fmt.Sprintf(`<?xml version="1.0" encoding="utf-8"?>
<root xmlns="urn:schemas-upnp-org:device-1-0">
  <specVersion><major>1</major><minor>0</minor></specVersion>
  <device>
    <deviceType>urn:schemas-upnp-org:device:MediaRenderer:1</deviceType>
    <friendlyName>%s</friendlyName>
    <manufacturer>自定义 DLNA</manufacturer>
    <modelName>Go MPV Renderer</modelName>
    <UDN>%s</UDN>
    <serviceList>
      <service>
        <serviceType>urn:schemas-upnp-org:service:AVTransport:1</serviceType>
        <serviceId>urn:upnp-org:serviceId:AVTransport</serviceId>
        <controlURL>/AVTransport/control</controlURL>
        <eventSubURL>/AVTransport/event</eventSubURL>
        <SCPDURL>/AVTransport/scpd.xml</SCPDURL>
      </service>
    </serviceList>
  </device>
</root>`, friendlyName, deviceUUID)

	w.Header().Set("Content-Type", "text/xml; charset=\"utf-8\"")
	fmt.Fprint(w, xml)
	log.Println("返回 description.xml")
}

func scpdHandler(w http.ResponseWriter, r *http.Request) {
	scpd := `<?xml version="1.0" encoding="utf-8"?>
<scpd xmlns="urn:schemas-upnp-org:service-1-0">
  <specVersion><major>1</major><minor>0</minor></specVersion>
  <actionList>
    <action>
      <name>SetAVTransportURI</name>
      <argumentList>
        <argument>
          <name>InstanceID</name>
          <direction>in</direction>
          <relatedStateVariable>A_ARG_TYPE_InstanceID</relatedStateVariable>
        </argument>
        <argument>
          <name>CurrentURI</name>
          <direction>in</direction>
          <relatedStateVariable>AVTransportURI</relatedStateVariable>
        </argument>
        <argument>
          <name>CurrentURIMetaData</name>
          <direction>in</direction>
          <relatedStateVariable>AVTransportURIMetaData</relatedStateVariable>
        </argument>
      </argumentList>
    </action>
    <action>
      <name>Play</name>
      <argumentList>
        <argument>
          <name>InstanceID</name>
          <direction>in</direction>
          <relatedStateVariable>A_ARG_TYPE_InstanceID</relatedStateVariable>
        </argument>
        <argument>
          <name>Speed</name>
          <direction>in</direction>
          <relatedStateVariable>TransportPlaySpeed</relatedStateVariable>
        </argument>
      </argumentList>
    </action>
    <action>
      <name>Pause</name>
      <argumentList>
        <argument>
          <name>InstanceID</name>
          <direction>in</direction>
          <relatedStateVariable>A_ARG_TYPE_InstanceID</relatedStateVariable>
        </argument>
      </argumentList>
    </action>
    <action>
      <name>Stop</name>
      <argumentList>
        <argument>
          <name>InstanceID</name>
          <direction>in</direction>
          <relatedStateVariable>A_ARG_TYPE_InstanceID</relatedStateVariable>
        </argument>
        </argumentList>
    </action>
    <action>
      <name>GetTransportInfo</name>
      <argumentList>
        <argument>
          <name>InstanceID</name>
          <direction>in</direction>
          <relatedStateVariable>A_ARG_TYPE_InstanceID</relatedStateVariable>
        </argument>
      </argumentList>
    </action>
  </actionList>
  <serviceStateTable>
    <stateVariable sendEvents="no">
      <name>A_ARG_TYPE_InstanceID</name>
      <dataType>ui4</dataType>
    </stateVariable>
    <stateVariable sendEvents="no">
      <name>TransportPlaySpeed</name>
      <dataType>string</dataType>
      <defaultValue>1</defaultValue>
    </stateVariable>
    <stateVariable sendEvents="yes">
      <name>TransportState</name>
      <dataType>string</dataType>
      <defaultValue>STOPPED</defaultValue>
      <allowedValueList>
        <allowedValue>STOPPED</allowedValue>
        <allowedValue>PLAYING</allowedValue>
      </allowedValueList>
    </stateVariable>
    <stateVariable sendEvents="yes">
      <name>TransportStatus</name>
      <dataType>string</dataType>
      <defaultValue>OK</defaultValue>
      <allowedValueList>
        <allowedValue>OK</allowedValue>
        <allowedValue>ERROR_OCCURRED</allowedValue>
      </allowedValueList>
    </stateVariable>
    <stateVariable sendEvents="yes">
      <name>AVTransportURI</name>
      <dataType>string</dataType>
    </stateVariable>
  </serviceStateTable>
</scpd>`

	w.Header().Set("Content-Type", "text/xml; charset=\"utf-8\"")
	w.Header().Set("Cache-Control", "no-cache, must-revalidate")
	fmt.Fprint(w, scpd)
	log.Println("返回 AVTransport scpd.xml")
}

func avTransportHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
		return
	}

	body, _ := io.ReadAll(r.Body)
	var env struct {
		XMLName xml.Name `xml:"Envelope"`
		Body    struct {
			SetURI *struct {
				InstanceID string `xml:"InstanceID"`
				CurrentURI string `xml:"CurrentURI"`
			} `xml:"SetAVTransportURI"`
			Play *struct {
				InstanceID string `xml:"InstanceID"`
				Speed      string `xml:"Speed"`
			} `xml:"Play"`
			GetTransportInfo *struct {
				InstanceID string `xml:"InstanceID"`
			} `xml:"GetTransportInfo"`
		} `xml:"Body"`
	}
	xml.Unmarshal(body, &env)

	soapAction := strings.Trim(r.Header.Get("SOAPACTION"), "\"")
	action := ""
	if idx := strings.LastIndex(soapAction, "#"); idx > 0 {
		action = soapAction[idx+1:]
	}

	var resp string
	switch action {
	case "SetAVTransportURI":
		if env.Body.SetURI != nil && env.Body.SetURI.InstanceID == "0" {
			currentURI = env.Body.SetURI.CurrentURI
			startMpv(currentURI)
			log.Printf("[SetURI] %s", currentURI)
			resp = `<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:SetAVTransportURIResponse xmlns:u="urn:schemas-upnp-org:service:AVTransport:1"/></s:Body></s:Envelope>`
		}
	case "Play":
		if env.Body.Play != nil && env.Body.Play.InstanceID == "0" && currentURI != "" {
			if mpvCmd == nil || mpvCmd.Process == nil {
				startMpv(currentURI)
			}
			resp = `<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:PlayResponse xmlns:u="urn:schemas-upnp-org:service:AVTransport:1"/></s:Body></s:Envelope>`
		}
	case "Pause":
		resp = `<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:PauseResponse xmlns:u="urn:schemas-upnp-org:service:AVTransport:1"/></s:Body></s:Envelope>`
	case "Stop":
		resp = `<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:StopResponse xmlns:u="urn:schemas-upnp-org:service:AVTransport:1"/></s:Body></s:Envelope>`
	case "GetTransportInfo":
		resp = `<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:GetTransportInfoResponse xmlns:u="urn:schemas-upnp-org:service:AVTransport:1"></u:GetTransportInfoResponse></s:Body></s:Envelope>`
	default:
		http.Error(w, "Unsupported SOAP action", http.StatusBadRequest)
		return
	}

	if resp != "" {
		w.Header().Set("Content-Type", "text/xml; charset=\"utf-8\"")
		fmt.Fprint(w, resp)
	} else {
		http.Error(w, "Bad Request", http.StatusBadRequest)
	}
}